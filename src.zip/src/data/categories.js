const categories = [
  {
    id: 1,
    title: "Generative AI",
    learners: "1.7M+",
    image: "/images/cat-ai.png"
  },
  {
    id: 2,
    title: "IT Certifications",
    learners: "14M+",
    image: "/images/cat-it.png"
  },
  {
    id: 3,
    title: "Data Science",
    learners: "8.1M+",
    image: "/images/cat-ds.png"
  }
];

export default categories;
